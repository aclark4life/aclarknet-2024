PUPUT_COMMENTS_PROVIDER = "puput.comments.DisqusCommentsProvider"
