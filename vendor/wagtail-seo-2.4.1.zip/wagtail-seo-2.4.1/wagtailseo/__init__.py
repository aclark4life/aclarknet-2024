release = ["2", "4", "1"]
__version__ = "{0}.{1}.{2}".format(release[0], release[1], release[2])
__shortversion__ = "{0}.{1}".format(release[0], release[1])
